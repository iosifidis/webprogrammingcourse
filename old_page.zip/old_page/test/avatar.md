---
sort: 7
---

# Avatar Test

```
{% raw %}{% avatar JV-conseil %}{% endraw %}
```

{% avatar JV-conseil %}

```tip
Set config `plugins: [jekyll-avatar]`

For documentation, see: [https://github.com/benbalter/jekyll-avatar](https://github.com/benbalter/jekyll-avatar)
```
